﻿namespace Class
{
    internal class User
    {
    }
}