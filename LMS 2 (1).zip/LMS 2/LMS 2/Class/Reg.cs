﻿using System;

namespace Class
{
    internal class Reg
    {
        internal void ShowDialog()
        {
            throw new NotImplementedException();
        }
    }
}