﻿using System;

namespace Class
{
    internal class ADMIN
    {
        internal void ShowDialog()
        {
            throw new NotImplementedException();
        }
    }
}